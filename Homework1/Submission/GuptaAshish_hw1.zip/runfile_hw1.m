cd('part1');
    run('run_me.m');
cd('../');
cd('part2');
    run('run_me.m');
cd('../');
    
