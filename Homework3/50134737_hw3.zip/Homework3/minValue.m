function min = minValue(val1,val2,val3)

    min = val1;
    
    if min > val2
        min = val2;
    end
    if(min > val3)
        min = val3;
    end
        
end