function dif = Difference( colorR , colorL )

    dif = abs(colorR-colorL);

end

